
#ifndef MASTER_H
#define MASTER_H

#include <string>
#include <list>

#include "../../agent_nix/src/datatypes.h"


  void readConfig (string filename );

  /**   */
  void SetBigList ( );


#endif // MASTER_H
