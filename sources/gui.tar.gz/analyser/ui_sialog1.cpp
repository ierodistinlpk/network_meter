#include <QtGui>
#include "ui_dialog1.h"

// ----------------------------------------------------------------------
Ui_Dialog::Ui_Dialog(QWidget* pwgt/*= 0*/)
     : QDialog(pwgt, Qt::WindowTitleHint | Qt::WindowSystemMenuHint)
{
setupUi(this);

    //Layout setup

}

// ----------------------------------------------------------------------
