#ifndef CONSTANTS_H
#define CONSTANTS_H
enum itemtype {Default,Agents,Probes,Events,Losted,Results,Targets,EventTypes};
enum graphtype {none, RttAvgComm, RttAvgTimed, RttAvgNumed, EventTimed, DataVolume, Correlation};
#endif // CONSTANTS_H
