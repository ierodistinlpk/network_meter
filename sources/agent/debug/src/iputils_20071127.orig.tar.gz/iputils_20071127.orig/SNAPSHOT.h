static char SNAPSHOT[] = "s20071127";
